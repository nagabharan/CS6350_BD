package Q4;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Main {

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();

		Job job = new Job(conf, "Combine age and friends list");
		job.setJarByClass(Main.class);
		job.setReducerClass(Reduce1.class);

		MultipleInputs.addInputPath(job, new Path(args[0]),
				TextInputFormat.class, Map1.class);

		MultipleInputs.addInputPath(job, new Path(args[1]),
				TextInputFormat.class, Map2.class);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		FileOutputFormat.setOutputPath(job, new Path(args[2]));

		job.waitForCompletion(true);

		JobConf conf2 = new JobConf();
		Job job2 = new Job(conf2, "job2");

		MultipleInputs.addInputPath(job2, new Path(args[2]),
				TextInputFormat.class, Map3.class);
		MultipleInputs.addInputPath(job2, new Path(args[1]),
				TextInputFormat.class, Map4.class);

		job2.setReducerClass(Reduce2.class);
		job2.setMapOutputKeyClass(Text.class);
		job2.setMapOutputValueClass(Text.class);
		job2.setOutputKeyClass(Text.class);
		job2.setOutputValueClass(DoubleWritable.class);
		job2.setJarByClass(Main.class);

		FileOutputFormat.setOutputPath(job2, new Path(args[3]));

		job2.waitForCompletion(true);

	}
}
