package Q3;

import java.net.URI;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Main {
	public static void main(String args[]) throws Exception {
		Configuration conf = new Configuration();
		conf.set("user1", args[4]);
		conf.set("user2", args[5]);
		Job job = Job.getInstance(conf, "Mutual Friends");
		job.setJarByClass(Main.class);
		job.setMapperClass(FriendMap.class);
		job.setReducerClass(FriendReduce.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		job.waitForCompletion(true);

		// Job2 details
		Job job2 = Job.getInstance(conf, "Mutual Friend Details");
		job2.setJarByClass(Main.class);
		job2.setMapperClass(FriendMap2.class);
		job2.setReducerClass(FriendReduce2.class);
		job2.setOutputKeyClass(Text.class);
		job2.setOutputValueClass(Text.class);
		job2.addCacheFile(new URI(args[1] + "/part-r-00000"));
		FileInputFormat.addInputPath(job2, new Path(args[2]));
		FileOutputFormat.setOutputPath(job2, new Path(args[3]));
		job2.waitForCompletion(true);
	}
}
