package Q4;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Map3 extends Mapper<LongWritable, Text, Text, Text> {

	private Text age = new Text();
	private Text userId = new Text();

	@Override
	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {

		// Split the line and for each friend Id output Friend Id as key and
		// age as value
		String[] linesplit = value.toString().split("\t");
		String[] userIdAndAge = linesplit[1].split(":");
		String[] userIdList = userIdAndAge[0].split(",");
		String tempAge = userIdAndAge[1];
		for (int i = 0; i < userIdList.length; i++) {
			String correctUserId = userIdList[i].replace("A", "");
			userId.set(correctUserId);
			age.set(tempAge);
			context.write(userId, age);

		}
	}
}
