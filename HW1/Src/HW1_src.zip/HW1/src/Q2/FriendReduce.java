package Q2;

import java.io.IOException;
import java.util.HashSet;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class FriendReduce extends Reducer<Text, Text, Text, Text> {
	private Text Q2 = new Text();

	// Calculates the common friends in the two list
	private String mutualFriendLister(String[] s1, String[] s2) {
		HashSet<String> h1 = new HashSet<String>();
		HashSet<String> h2 = new HashSet<String>();

		for (int i = 0; i < s1.length; i++) {
			h1.add(s1[i]);
		}
		for (int i = 0; i < s2.length; i++) {
			h2.add(s2[i]);
		}

		h1.retainAll(h2);
		String[] res = h1.toArray(new String[0]);
		String mutuals = new String("");
		for (int i = 0; i < res.length; i++) {
			mutuals += res[i] + ",";
		}

		return mutuals;
	}

	public void reduce(Text key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {
		// Keep the combined friends as an array
		String[][] combined = new String[2][];
		int cur = 0;
		for (Text value : values) {
			String friends = value.toString();
			String[] frinedList = friends.split(",");
			combined[cur++] = frinedList;
		}

		// Calculate the common friends and put them in the mutual friends.
		// If no list is empty then only call common friends finder
		if (combined[0] != null && combined[1] != null)
			Q2.set(mutualFriendLister(combined[0], combined[1]));
		else
			Q2.set("No Mutual friends found");

		context.write(key, Q2);

	}
}
