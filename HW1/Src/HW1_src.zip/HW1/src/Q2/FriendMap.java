package Q2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class FriendMap extends Mapper<LongWritable, Text, Text, Text> {

	private Text mutualFriends = new Text();
	private Text tmp = new Text();

	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {

		String eachLine = value.toString();

		Configuration conf = context.getConfiguration();
		String user1 = conf.get("user1");
		String user2 = conf.get("user2");

		int index = eachLine.indexOf('\t');
		if (index == -1)
			return;

		String userID = eachLine.substring(0, index);
		List<String> friendsIDs = new ArrayList<String>();
		StringTokenizer tokenizer = new StringTokenizer(
				eachLine.substring(index + 1), "" + ',');
		while (tokenizer.hasMoreTokens()) {
			friendsIDs.add(tokenizer.nextToken());
		}

		tmp.set(user1 + " " + user2);
		if (userID.equalsIgnoreCase(user1) || userID.equalsIgnoreCase(user2)) {
			String friends = eachLine.replace(userID + "\t", "");
			mutualFriends.set(friends);
			context.write(tmp, mutualFriends);
		}

	}
}
