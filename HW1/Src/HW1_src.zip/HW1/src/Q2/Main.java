package Q2;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Main {
	public static void main(String args[]) throws Exception {
		Configuration conf = new Configuration();
		conf.set("user1", args[2]);
		conf.set("user2", args[3]);
		Job job = Job.getInstance(conf, "Mutual Friends");
		job.setJarByClass(Main.class);
		job.setMapperClass(FriendMap.class);
		job.setReducerClass(FriendReduce.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
