package Q4;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Map2 extends Mapper<LongWritable, Text, Text, Text> {
	private Text userId = new Text();
	private Text age = new Text();

	// Function to calculate age
	int calcualteAge(String dob) {
		// Since we do not know the age, substract the year from 2016
		String[] dobFields = dob.split("/");
		String year = dobFields[2];
		int age = 2016 - Integer.parseInt(year);
		return age;
	}

	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		String[] fields = value.toString().split(",");
		userId.set(fields[0]);
		String dob = fields[9].trim();
		Integer intAge = calcualteAge(dob);
		age.set(intAge.toString());
		context.write(userId, age);

	}
}
