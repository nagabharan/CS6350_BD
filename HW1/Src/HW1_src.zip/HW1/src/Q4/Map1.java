package Q4;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Map1 extends Mapper<LongWritable, Text, Text, Text> {

	@Override
	protected void setup(Context context) throws IOException,
			InterruptedException {
		super.setup(context);
	}

	private Text userId = new Text();
	private Text friendsList = new Text();

	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		String[] fields = value.toString().split("\t");
		if (fields.length < 2)
			return;
		userId.set(fields[0].trim());
		friendsList.set(fields[1].trim() + "A");
		context.write(userId, friendsList);

	}
}
