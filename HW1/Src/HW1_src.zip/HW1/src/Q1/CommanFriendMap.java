package Q1;

import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class CommanFriendMap extends
		Mapper<LongWritable, Text, Text, IntWritable> {
	private final static IntWritable one = new IntWritable(1); // 2 common
																// friends
	private final static IntWritable two = new IntWritable(0); // already
																// friend

	@Override
	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		String line = value.toString();
		int index = line.indexOf('\t');
		if (index == -1)
			return;
		String user_id = line.substring(0, index);
		Vector<String> friends_id = new Vector<String>();
		StringTokenizer tokenizer = new StringTokenizer(
				line.substring(index + 1), "" + ',');
		while (tokenizer.hasMoreTokens()) {
			friends_id.add(tokenizer.nextToken());
		}
		int length = friends_id.size(), i, j;
		for (i = 0; i < length; i++) {
			context.write(new Text(user_id + ',' + friends_id.elementAt(i)),
					two);
		}
		for (i = 0; i < length; i++) {
			for (j = 0; j < length; j++) {
				if (j == i)
					continue;
				context.write(new Text(friends_id.elementAt(i) + ','
						+ friends_id.elementAt(j)), one);
			}
		}
	}
}
