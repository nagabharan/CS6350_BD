package Q1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Vector;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class CommanFriendReduce2 extends Reducer<Text, Text, Text, Text> {

	@Override
	public void reduce(Text key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {

		ArrayList<Text> wantedKeys = new ArrayList<Text>();

		wantedKeys.add(new Text("924"));
		wantedKeys.add(new Text("8941"));
		wantedKeys.add(new Text("8942"));
		wantedKeys.add(new Text("9019"));
		wantedKeys.add(new Text("9020"));
		wantedKeys.add(new Text("9021"));
		wantedKeys.add(new Text("9022"));
		wantedKeys.add(new Text("9990"));
		wantedKeys.add(new Text("9992"));
		wantedKeys.add(new Text("9993"));

		Vector<int[]> mostCommon = new Vector<int[]>();
		// add friend id to the mostCommon array in order
		for (Text val : values) {

			if (val != null) {
				String val_str = val.toString();
				int index;
				if ((index = val_str.indexOf(',')) == -1)
					return;
				int[] pair_array = new int[2];

				String val0 = val_str.substring(0, index);
				String val1 = val_str.substring(index + 1);
				if (null != val0)
					pair_array[0] = Integer.parseInt(val0);
				if (null != val1)
					pair_array[1] = Integer.parseInt(val1);

				if (mostCommon.isEmpty())
					mostCommon.insertElementAt(pair_array, 0);
				else {
					int i;
					for (i = 0; i < Math.min(mostCommon.size(), 10); i++) {
						if (mostCommon.get(i)[1] < pair_array[1]
								|| (mostCommon.get(i)[1] == pair_array[1] && mostCommon
										.get(i)[0] > pair_array[0])) {
							mostCommon.insertElementAt(pair_array, i);
							while (mostCommon.size() > 10)
								mostCommon
										.removeElementAt(mostCommon.size() - 1);
							break;
						}
					}
					if (i == mostCommon.size() && i < 10)
						mostCommon.add(pair_array);
				}
			}

		}
		String mostCommon_str = "";
		for (int i = 0; i < mostCommon.size(); i++) {
			mostCommon_str += Integer.toString(mostCommon.get(i)[0]);
			if (i != mostCommon.size() - 1)
				mostCommon_str += ',';
		}
		if (wantedKeys.contains(key)) {
			context.write(key, new Text(mostCommon_str));
		}

	}
}
