package Q4;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Set;
import java.util.TreeMap;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Reduce2 extends Reducer<Text, Text, Text, DoubleWritable> {

	public static TreeMap<Double, ArrayList<String>> UsersByFriendsAge = new TreeMap<Double, ArrayList<String>>(
			Collections.reverseOrder());

	@Override
	public void reduce(Text key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {

		double sumAge = 0;
		double count = 0;
		double average = 0;
		String nameAndAdress = "";

		for (Text val : values) {
			if (val.toString().contains("flagA")) {
				nameAndAdress = val.toString();
				nameAndAdress = nameAndAdress.replace("flagA", "");
				continue;
			}
			sumAge += Double.parseDouble(val.toString());
			count++;
		}

		// getting the average of friends for each user.
		average = sumAge / count;

		if (!Double.isNaN(average)) {
			// If user doesnt exist create the spot in the tree map
			if (UsersByFriendsAge.get(average) == null) {
				ArrayList<String> usersList = new ArrayList<String>();
				usersList.add(key.toString() + "::" + nameAndAdress);
				// System.out.println("name and address " + nameAndAdress) ;
				UsersByFriendsAge.put(average, usersList);

			} else {
				// Add the user to the list of users having same average.
				ArrayList<String> usersList = UsersByFriendsAge.get(average);
				usersList.add(key.toString() + "::" + nameAndAdress);
				UsersByFriendsAge.put(average, usersList);
			}
		}

	}

	public void cleanup(Context context) throws IOException,
			InterruptedException {
		Text userNameAndAdress = new Text();
		DoubleWritable averageFriendsAge = new DoubleWritable();
		Set<Double> ages = UsersByFriendsAge.keySet();

		int count = 0;

		for (Double age : ages) {
			ArrayList<String> userDetails = UsersByFriendsAge.get(age);

			for (String userDetail : userDetails) {
				if (count == 20)
					break;
				String[] fields = userDetail.split("::");
				System.out.println("final field is " + fields[1]);
				String nameAndAdress = fields[1];
				userNameAndAdress.set(nameAndAdress);
				averageFriendsAge.set(age);
				context.write(userNameAndAdress, averageFriendsAge);
				count++;
			}
		}
	}
}
