package Q4;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Reduce1 extends Reducer<Text, Text, Text, Text> {
	private Text userId = new Text();
	private Text friendListAndAge = new Text();

	public void reduce(Text key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {

		ArrayList<String> ageAndfriendsList = new ArrayList<String>();
		String details = "";
		String temp = "";

		int flag = 0;
		int count = 0;
		// Generate details as list of friends | age of the user"
		for (Text value : values) {

			if (value.toString().contains("A")) {
				if (temp.length() < 1) {
					details = value.toString() + ":";
				} else {
					details = value.toString() + ":" + temp;
				}
				count++;
			} else {
				if (details.length() < 1) {
					temp = value.toString();
					continue;
				}

				else {
					details += value.toString();
				}
				count++;
			}

		}
		userId.set(key.toString());
		friendListAndAge.set(details);
		if (count == 2)
			context.write(userId, friendListAndAge);

	}
}
