package Q3;

import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class FriendMap extends Mapper<LongWritable, Text, Text, Text> {

	private Text personFriends = new Text();
	private Text tempKey = new Text();

	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {

		String eachLine = value.toString();

		Configuration conf = context.getConfiguration();
		String user1 = conf.get("user1");
		String user2 = conf.get("user2");
		int index = eachLine.indexOf('\t');
		if (index == -1)
			return;
		String userName = eachLine.substring(0, index);
		ArrayList<String> friendList = new ArrayList<String>();
		StringTokenizer tokenizer = new StringTokenizer(
				eachLine.substring(index + 1), "" + ',');

		while (tokenizer.hasMoreTokens()) {
			friendList.add(tokenizer.nextToken());
		}

		tempKey.set(user1 + " " + user2);
		if (userName.equalsIgnoreCase(user1)
				|| userName.equalsIgnoreCase(user2)) {
			String friends = eachLine.replace(userName + "\t", "");
			personFriends.set(friends);
			context.write(tempKey, personFriends);

		}

	}
}
