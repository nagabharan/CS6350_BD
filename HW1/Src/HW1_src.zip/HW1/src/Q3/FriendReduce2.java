package Q3;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class FriendReduce2 extends Reducer<Text, Text, Text, Text> {

	public void reduce(Text key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {
		Text friendsDetail = new Text();
		String detail = "[";
		for (Text value : values) {
			detail += value.toString() + ",";
		}
		// Remove an extra comma at at the end
		detail = detail.substring(0, detail.length() - 1);
		detail += "]";
		friendsDetail.set(detail);
		context.write(key, friendsDetail);
		System.out.println(key.toString() + " " + friendsDetail.toString());

	}
}
