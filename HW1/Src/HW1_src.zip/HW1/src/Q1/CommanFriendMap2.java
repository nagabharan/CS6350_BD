package Q1;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class CommanFriendMap2 extends Mapper<LongWritable, Text, Text, Text> {
	@Override
	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		String line = value.toString();

		int index, index2;
		if ((index = line.indexOf(',')) == -1)
			return;
		if ((index2 = line.indexOf('\t')) == -1)
			return;
		String user_id = line.substring(0, index);
		String friend_id = line.substring(index + 1, index2);
		String commonFriend = line.substring(index2 + 1);
		context.write(new Text(user_id), new Text(friend_id + ','
				+ commonFriend));
	}
}
