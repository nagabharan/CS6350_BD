package Q3;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.HashMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class FriendMap2 extends Mapper<LongWritable, Text, Text, Text> {

	static String intermediateOutputLine = "";
	static HashMap<String, String> map = new HashMap<String, String>();

	@Override
	protected void setup(Context context) throws IOException,
			InterruptedException {

		URI[] files = context.getCacheFiles();

		if (files.length == 0) {
			throw new FileNotFoundException(
					"file not found in distributed Cache");
		}
		FileSystem fs = FileSystem.get(context.getConfiguration());
		FSDataInputStream in = fs.open(new Path(files[0]));
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		readCacheFile(br);
	};

	private void readCacheFile(BufferedReader br) throws IOException {
		String line = br.readLine();
		while (line != null) {
			String[] fields = line.split("\t");
			String[] friends = fields[1].split(",");
			// Put Id as a key and name:zipcode as the value
			for (int i = 0; i < friends.length; i++) {
				map.put(friends[i].trim(), "Ignore");
			}
			line = br.readLine();
		}
	}

	@Override
	protected void map(LongWritable key, Text value,
			Mapper<LongWritable, Text, Text, Text>.Context context)
			throws IOException, InterruptedException {

		Text userIds = new Text();
		Text nameAndZipCode = new Text();
		Configuration conf = context.getConfiguration();
		String user1 = conf.get("user1");
		String user2 = conf.get("user2");

		intermediateOutputLine = value.toString();
		String[] fields = intermediateOutputLine.split(",");
		// Field seven contains the ids of mutual friend
		String[] friendDetails = fields[1].split(",");
		// Find the zip code and name for each friend
		String userId = fields[0];
		String firstName = fields[1];
		String zipCode = fields[7];
		String details = "";
		if (map.containsKey(userId)) {
			details += firstName + ":" + zipCode;
			userIds.set(user1 + " " + user2);
			nameAndZipCode.set(details);
			context.write(userIds, nameAndZipCode);
			System.out.println(userIds.toString() + " "
					+ nameAndZipCode.toString());
		}

	}
}
