package Q4;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Map4 extends Mapper<LongWritable, Text, Text, Text> {

	private Text userId = new Text();
	private Text nameAndAddress = new Text();

	@Override
	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		String[] line = value.toString().split(",");
		String id = line[0];
		String name = line[1];
		String streetAddress = line[3];
		String city = line[4];
		String state = line[5];

		String address = streetAddress + "," + city + "," + state;
		userId.set(id);
		nameAndAddress.set(name + "," + address + "flagA");
		context.write(userId, nameAndAddress);
	}
}
